public class ClasseSocial {
    public static void main(String[] args) {
        System.out.println("Digite sua renda: \n");

        TesteClasseSocial social  = new TesteClasseSocial();

        social.resposta();

        System.out.println(social);


    }
}
