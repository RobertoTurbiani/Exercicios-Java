public class NumerosPares {
    public static void main(String[] args) {
        Integer pares = 0;

        for (int i = 0; i <= 90 ; i++) {

            if (i % 2 == 0){
                System.out.println(i);
            }

        }
    }
}
