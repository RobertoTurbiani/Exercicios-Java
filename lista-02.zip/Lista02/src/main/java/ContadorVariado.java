public class ContadorVariado {
    public static void main(String[] args) {

        Double fracao = 0.15;

        for (fracao = 0.15; fracao < 5; fracao+= 0.15) {

            System.out.println(fracao);

        }

    }
}
