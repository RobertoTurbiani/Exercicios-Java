public class NumerosImpares {
    public static void main(String[] args) {

        Integer impares = 0;

        for (int i = 0; i <= 90 ; i++) {
            if (i % 2 == 1){
                System.out.println(i);
            }

        }
    }
}
